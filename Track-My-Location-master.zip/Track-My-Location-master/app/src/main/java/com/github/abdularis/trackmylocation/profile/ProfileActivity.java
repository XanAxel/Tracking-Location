package com.github.abdularis.trackmylocation.profile;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.abdularis.trackmylocation.R;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }
}
